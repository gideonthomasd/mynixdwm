static void inplacerotate(const Arg *arg);

