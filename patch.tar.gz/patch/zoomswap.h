static Client *findbefore(Client *c);

