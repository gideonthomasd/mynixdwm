static void grid(Monitor *m);

