#if FIBONACCI_DWINDLE_LAYOUT
static void dwindle(Monitor *m);
#endif // FIBONACCI_DWINDLE_LAYOUT
static void fibonacci(Monitor *m, int s);
#if FIBONACCI_SPIRAL_LAYOUT
static void spiral(Monitor *m);
#endif // FIBONACCI_SPIRAL_LAYOUT

