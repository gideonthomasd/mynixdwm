static void warp(const Client *c);

