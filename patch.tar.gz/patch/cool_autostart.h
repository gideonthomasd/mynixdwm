static void autostart_exec(void);

